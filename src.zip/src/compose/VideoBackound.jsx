const VideoBackound = ({ src, overlayOpacity = "bg-black/60", children }) => {
  return (
    <div className="relative w-full h-screen overflow-hidden">
      {/*�v�� */}
      <video
        autoPlay
        muted
        loop
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover z-[-2]"
      >
        <source src={src} type="video/mp4" />
      </video>

      {/* �b�z���B�n */}
      <div
        className={`absolute top-0 left-0 w-full h-full ${overlayOpacity} z-[-1]`}
      />

      {/* ����϶�*/}
      <div className="relative z-10 w-full h-full">{children}</div>
    </div>
  );
};
export default VideoBackound;
