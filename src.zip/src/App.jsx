import "./App.css";
import ProfileIntro from "./compose/introPage/ProfileIntro";
import ProjectShowcase from "./compose/introPage/ProjectShowcase";

import VideoBackound from "./compose/VideoBackound"; // 如果你不想改檔名

import TerminalPage from "./compose/cmdPage/TerminalPage";

import { BrowserRouter, Routes, Route } from "react-router-dom";


// import HeroPage from "./components/HeroPage";
// import Intro from "./components/Intro";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <VideoBackound src="/code.mp4">
              <div className="flex flex-col items-center md:flex-row w-full h-full items-start gap-8 px-8">
                <aside className="w-full md:w-[420px]">
                  <ProfileIntro />
                </aside>

                <main className="flex-1 max-h-[450px] overflow-y-auto">
                  <ProjectShowcase />
                </main>
              </div>
            </VideoBackound>
          }
        />
        <Route path="/panel" element={<TerminalPage/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
